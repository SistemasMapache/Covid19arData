En este Dropbox compartimos los datos públicos sobre COVID19 para alivianar al servidor del Ministerio de Salud que está saturado por la demanda.

Los links se bajaron entre la noche del 14-5 y la mañana del 15-5 de las siguientes URL
casos:
http://datos.salud.gob.ar/dataset/covid-19-casos-registrados-en-la-republica-argentina/archivo/c9ce10a1-0cac-4ed7-9486-7d437cf2cea1

determinaciones (tests):
http://datos.salud.gob.ar/dataset/covid-19-determinaciones-registradas-en-la-republica-argentina/archivo/08104e8d-7db2-4816-8d76-efb871fa3137
